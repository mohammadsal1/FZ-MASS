// generated from rosidl_generator_c/resource/idl.h.em
// with input from qcar2_interfaces:msg/BooleanLeds.idl
// generated code does not contain a copyright notice

#ifndef QCAR2_INTERFACES__MSG__BOOLEAN_LEDS_H_
#define QCAR2_INTERFACES__MSG__BOOLEAN_LEDS_H_

#include "qcar2_interfaces/msg/detail/boolean_leds__struct.h"
#include "qcar2_interfaces/msg/detail/boolean_leds__functions.h"
#include "qcar2_interfaces/msg/detail/boolean_leds__type_support.h"

#endif  // QCAR2_INTERFACES__MSG__BOOLEAN_LEDS_H_
