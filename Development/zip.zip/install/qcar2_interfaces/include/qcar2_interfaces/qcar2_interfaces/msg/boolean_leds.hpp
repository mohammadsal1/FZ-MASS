// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef QCAR2_INTERFACES__MSG__BOOLEAN_LEDS_HPP_
#define QCAR2_INTERFACES__MSG__BOOLEAN_LEDS_HPP_

#include "qcar2_interfaces/msg/detail/boolean_leds__struct.hpp"
#include "qcar2_interfaces/msg/detail/boolean_leds__builder.hpp"
#include "qcar2_interfaces/msg/detail/boolean_leds__traits.hpp"

#endif  // QCAR2_INTERFACES__MSG__BOOLEAN_LEDS_HPP_
