// generated from rosidl_generator_c/resource/idl.h.em
// with input from qcar2_interfaces:msg/MotorCommands.idl
// generated code does not contain a copyright notice

#ifndef QCAR2_INTERFACES__MSG__MOTOR_COMMANDS_H_
#define QCAR2_INTERFACES__MSG__MOTOR_COMMANDS_H_

#include "qcar2_interfaces/msg/detail/motor_commands__struct.h"
#include "qcar2_interfaces/msg/detail/motor_commands__functions.h"
#include "qcar2_interfaces/msg/detail/motor_commands__type_support.h"

#endif  // QCAR2_INTERFACES__MSG__MOTOR_COMMANDS_H_
