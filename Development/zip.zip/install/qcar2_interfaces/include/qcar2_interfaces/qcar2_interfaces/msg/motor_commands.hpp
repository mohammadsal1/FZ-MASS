// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef QCAR2_INTERFACES__MSG__MOTOR_COMMANDS_HPP_
#define QCAR2_INTERFACES__MSG__MOTOR_COMMANDS_HPP_

#include "qcar2_interfaces/msg/detail/motor_commands__struct.hpp"
#include "qcar2_interfaces/msg/detail/motor_commands__builder.hpp"
#include "qcar2_interfaces/msg/detail/motor_commands__traits.hpp"

#endif  // QCAR2_INTERFACES__MSG__MOTOR_COMMANDS_HPP_
